<?php
$ir="login.php";
$us="usuario";
$car="cargo";
$num=3;
?>