<link rel="icon" href="red_local.ico" type="image/x-icon" />
<title>Red local</title>
<body style="background-image: url(imagenes/red.png); background-position: center center; background-repeat: no-repeat; background-attachment: fixed; background-size: cover; background-color: #66999;">
<?php 

$ip = getHostByName(getHostName());

echo "<p style='text-align:center; font-size:100px;'> <font face='univers' color='black'><b> La dirección del Examen Local </b></font> </p>";
echo "<p style='font-weight:bold; text-align:center; font-size:100px;'> <font  face='univers' color='blue'> ".$ip."/xampp/star/  </font> </p>";
?>
