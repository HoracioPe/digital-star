
</div><!--CIERRA EL DIV DEL CONTAINER-->
</div>
<div style="height: 120px;">

  
</div>
<footer class="footer container-fluid bg-dark mt-1">


    <div class="row d-flex justify-content-end text-white">

                <div class="col-12 col-md-7 text-md-right">
                    <h1>
                    <!--Facebook-->
                    <a class="fb-ic ml-0">
                    <a href="https://web.facebook.com/Universidad-Tecnol%C3%B3gica-De-Tlaxcala-155983347830609">
                        <i class="fab fa-facebook-square mr-0"></i>
                    </a>
                    <!--Twitter-->
                    <a class="tw-ic">
                    <a href="https://twitter.com/login?lang=es">
                        <i class="fab fa-twitter-square mr-0"></i>
                    </a>
                    <!--Google +-->
                    <a class="gplus-ic">
                     <a href="https://www.universia.net.mx/universidades/universidad-tecnologica-tlaxcala/in/30273">
                        <i class="fab fa-google mr-0"></i>
                    </a>
                    <!--<a href="#"><i class="fas fa-arrow-circle-up"></i></a>-->
                  </h1>
                </div>
                <!--Grid column-->
      
      </div>
      <div class="row">
        <div class="col-12 text-center pb-3 text-white">
        ** PLATAFORMA DE EXÁMENES ESCOLARES **
        <a href="https://www.uttlaxcala.edu.mx/#">
            <strong class="text-warning"> UTTlaxcala</strong>
        </a>

      </div>
      </div>

</footer>
       



    <script src="js/popper.min.js"></script>

<script src="../js/jquery-3.2.1.min.js"></script>
<script src="../js/bootstrap.js"></script>

<script>
    	$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
</script>

  </body>
</html>
