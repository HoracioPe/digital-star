<!-- Código para bloquear el boton hacia atras del navegador-->

<script Language="JavaScript">
if(history.forward(1)){
history.replace(history.forward(1));
}
</script>


<!-- Fin del Código para bloquear el boton hacia atras del navegador-->
<?php 


  include("../sesion.class.php");
  include("../conexion.php");
  
$sesion=new sesion();
$cargo=$sesion->get("cargo");
$usuario=$sesion->get("usuario");
if ($cargo=='3') { ?>
<?php include("top-estudiantes.php");

$id_examen=$_GET['id'];
$ci=$_GET['ci'];

?>
<!--Agrege este codigo para que se viera bien en el telefono junto con un div de hasta abajo-->
<main role="main">
<section class="jumbotron text-left">
        <div class="container">
<!--______________________________________-->
<?php

$veri="SELECT * FROM cuestionarios WHERE ci='$usuario' AND id_examen='$id_examen' ";
$fol=$link->query($veri);
while ($rod=$fol->fetch_array()) {
  $ran1=$rod['ran1'];
}

if ($ran1>0) {
 echo "<div class='text-center p-4 text-warning bg-secondary'> <h3>!! Usted ya hizo el examen </h3>";
 echo "<a href='final.php?id_examen=$id_examen' class='btn btn-success'> Ver Puntaje</a></div>";
}
else{ 



$consulta="SELECT * FROM examen WHERE id='$id_examen' ";
if ($resultado=$link->query($consulta)) {
         while ($row=$resultado->fetch_assoc()) {
             $id=$row['id'];
             $categoria=$row['categoria'];
             $titulo=$row['titulo'];
             $consigna=$row['consigna'];
             $tiempo=$row['tiempo'];

             
 } }       
?>



    <!-- Begin page content -->
    <main role="main" class="container">
    	<h1 class="mt-5">Bienvenido a la Evaluacion de :<?php echo utf8_decode($titulo);?></h1>
      <p class="lead">Solo tienes un intento, una vez que comienza  no hay marcha atras</p>
<div class="alert alert-danger alert-dismissable">
  <button type="button" class="close" data-dismiss="alert">&times;</button>
 ¿Comenzamos la Evaluación?<br>
  <strong>¡Mucho OjO!</strong> Tiene un máximo de 
<?php 
	if ($tiempo==1) {
echo "<strong><font style='font-size: 20px;font-stretch: bold;'>".$tiempo." minuto </font></strong>";    
}else{
  echo "<strong><font style='font-size: 20px;font-stretch: bold;'>".$tiempo." minutos </font></strong>";
}
	


?>

X pregunta para resolver la evaluación

</div>
<form action="prep.php" method="get">
<input type="hidden" name="ci" value="<?php echo $ci;?>">
<input type="hidden" name="id_examen" value="<?php echo $id_examen;?>">
<input type="hidden" name="tiempo" value="<?php echo $tiempo;?>">
<?php echo "<a href='principal.php'><button type='button' class='btn btn-dark' style='float: left;''> <i class='fas fa fa-reply fa-1x'></i> REGRESAR </button></a>";?>

<button type="submit" class="btn btn-primary" style="float: right;"> COMENZAR EXAMEN <i class="fas fa-play-circle fa-1x"></i> </button>
</div><!--Aumente es div-->
<script>
window.location.hash="no-back-button";
window.location.hash="Again-No-back-button";//again because google chrome don't insert first hash into history
window.onhashchange=function(){window.location.hash="no-back-button";}
</script> 
</form>	
    </main>

    
    <footer class="footer">
      <div class="container">

      </div>
    </footer>
    
    
<?php include("footer-examen.php");?>

</body>
</html>


<?php  }

}else{
  echo "No eres Administrador y No tienes Permiso para ver esta pagina ";
  echo "<a href ='../index.php' > REGRESAR </a>";
}?>