<?php

$link= new mysqli("localhost","root","","evaluacion") or die("Error " . mysqli_error($link));

?>