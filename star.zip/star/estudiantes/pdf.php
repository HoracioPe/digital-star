
<?php 
 //header("Content-Type: text/html; charset=iso-8859-1 ");
  include("../sesion.class.php");
  include("../conexion.php");
$sesion=new sesion();
$cargo=$sesion->get("cargo");
$usuario=$sesion->get("usuario");
if ($cargo=='3') { 

require('../pdf/fpdf.php');
include("../conexion.php");

//CONTROLES DEL GET
$id_examen=$_GET['id_examen'];

$cons="SELECT * FROM examen WHERE id='$id_examen' ";
if ($re=$link->query($cons)) {
         while ($ro=$re->fetch_assoc()) {
             $id=$ro['id'];
             $categoria=$ro['categoria'];
             $titulo=$ro['titulo'];
             $consigna=$ro['consigna'];

             
 } }    
 $consul="SELECT * FROM dat_admin WHERE ci='$usuario' AND cargo='3' ";
if ($resu=$link->query($consul)) {
         while ($rof=$resu->fetch_assoc()) {
             $ap=$rof['ap'];
             $am=$rof['am'];
             $nom=$rof['nom'];
             $nivel=$rof['nivel'];
             $curso=$rof['curso'];
             $paralelo=$rof['paralelo'];

          

             
 } } 


$consulta="SELECT *,sum(act1+act2+act3+act4+act5+act6+act7+act8+act9+act10) as total FROM cuestionarios WHERE ci='$usuario' AND id_examen='$id_examen' ";
$resultado=$link->query($consulta);
while ($row=$resultado->fetch_array()) {
$ap=$row['ap'];
$am=$row['am'];
$nom=$row['nom'];

$ran1=$row['ran1'];
$ran2=$row['ran2'];
$ran3=$row['ran3'];
$ran4=$row['ran4'];
$ran5=$row['ran5'];
$ran6=$row['ran6'];
$ran7=$row['ran7'];
$ran8=$row['ran8'];
$ran9=$row['ran9'];
$ran10=$row['ran10'];

$resp1a=$row['resp1'];
$resp2a=$row['resp2'];
$resp3a=$row['resp3'];
$resp4a=$row['resp4'];
$resp5a=$row['resp5'];
$resp6a=$row['resp6'];
$resp7a=$row['resp7'];
$resp8a=$row['resp8'];
$resp9a=$row['resp9'];
$resp10a=$row['resp10'];

$total=$row['total'];}       

// HASTA AQUI LOS CONTROLES DEL GET
$pdf = new FPDF('P','mm',array(215,330));//tamaño OFICIO
#Establecemos los márgenes izquierda, arriba y derecha:
$pdf->SetMargins(10, 10 , 10);
#Establecemos el margen inferior:
$pdf->SetAutoPageBreak(true,10); 

$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 15);
$pdf->Ln(7);
$pdf->Image('imagenes/logoutt.jpg' , 30 ,4, 30 , 23,'JPG');
$pdf->Cell(60, 7, '', 0);
$pdf->Cell(70, 7, 'Evaluación de '.$categoria, 0,0,'B');//IMPORTANTE TRABAJAR CON 1 PARA VER LOS CUADROS
$pdf->Image('imagenes/Logo-vertical.png' , 160 ,4, 20 , 20,'PNG');
$pdf->Ln(9);

$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(10, 10, '', 0);
$pdf->Cell(10, 10, 'DATOS REFERENCIALES', 0);
$pdf->Ln(8);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(15, 6, '', 0);
$pdf->Cell(15, 6, 'Titulo', 0);
$pdf->Cell(3, 6, ':', 0);
$pdf->SetFont('Arial', '', 9);
$pdf->Cell(50, 6, $titulo, 0);
$pdf->Cell(25, 6, '', 0);
$pdf->Cell(15, 6, 'Grado ', 0);
$pdf->Cell(3, 6, ':', 0);
if ($curso=='PRIMERO') {
$pdf->Cell(50, 6, "1° ".$paralelo." ".$nivel, 0);
}elseif ($curso=='SEGUNDO') {
$pdf->Cell(50, 6, "2° ".$paralelo." ".$nivel, 0);
}elseif ($curso=='TERCERO') {
$pdf->Cell(50, 6, "3° ".$paralelo." ".$nivel, 0);
}elseif ($curso=='CUARTO') {
$pdf->Cell(50, 6, "4° ".$paralelo." ".$nivel, 0);
}elseif ($curso=='QUINTO') {
$pdf->Cell(50, 6, "5° ".$paralelo." ".$nivel, 0);
}elseif ($curso=='SEXTO') {
$pdf->Cell(50, 6, "6° ".$paralelo." ".$nivel,0);
}else{
$pdf->Cell(50, 6, $curso." ".$paralelo." ".$nivel, 0);
}

$pdf->Ln(5);

$pdf->SetFont('Arial', '', 10);
$pdf->Cell(15, 6, '', 0);
$pdf->Cell(15, 6, utf8_decode('Nombre'), 0);
$pdf->Cell(3, 6, ':', 0);
$pdf->SetFont('Arial', '', 9);
$pdf->Cell(50, 6, utf8_decode($nom." ".$ap." ".$am), 0);
$pdf->Cell(25, 6, '', 0);
$pdf->Cell(15, 6, 'Puntaje ', 0);
$pdf->Cell(3, 6, ':', 0);
$pdf->Cell(50, 6, $total.' Puntos', 0);
$pdf->Ln(6);
$pdf->Cell(190, 6, '----------------------------------------------------------------------------------------------------------------------------------------------------------------', 0,0,'C');
$pdf->Ln(6);
// desde aqui la PREGUNTA # 1
$pregunta1="SELECT * FROM preguntas WHERE id_examen='$id_examen' AND numero='$ran1' ";
$res1=$link->query($pregunta1);
while ($row1=$res1->fetch_array()) {
$preg1=$row1['preg'];
$resp1=$row1['resp'];
$A1=$row1['A'];
$B1=$row1['B'];
$C1=$row1['C'];
$D1=$row1['D'];
}

$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(10, 5, '', 0);
$pdf->SetTextColor(0, 255, 0);
$pdf->Cell(20, 5, 'Pregunta 1. ', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(140, 5, $preg1, 0);
$pdf->Ln(4);

$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(A)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($A1), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(B)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($B1), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(C)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($C1), 0);
$pdf->Ln(4);
//aqui le menie para que el texo se acoplara a la pregunta
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(D)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($D1), 0);
$pdf->Ln(4);
if($resp1 == $A1){
  $resp1= "A";
}
if($resp1 == $B1){
  $resp1= "B";
}
if($resp1 == $C1){
  $resp1= "C";
}
if($resp1 == $D1){
  $resp1= "D";
}
$pdf->SetFont('Helvetica', 'B', 8);
$pdf->Cell(20, 5, '', 0);
$pdf->Cell(29, 5, utf8_decode('Respuesta Correcta'), 0);
$pdf->Cell(3, 5, ':', 0);
$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(60, 5, $resp1, 0);

if($resp1a == $A1){
  $resp1a= "A";
}
if($resp1a == $B1){
  $resp1a= "B";
}
if($resp1a == $C1){
  $resp1a= "C";
}
if($resp1a == $D1){
  $resp1a= "D";
}

$pdf->SetFont('Helvetica', 'B', 8);
$pdf->Cell(19, 4, utf8_decode('Tu respuesta'), 0);
$pdf->Cell(3, 4, ':', 0);
$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(60, 4, $resp1a, 0);
$pdf->Ln(4);

// HASTA AQUI PREGUNTA # 1

// desde aqui la PREGUNTA # 2
$pregunta2="SELECT * FROM preguntas WHERE id_examen='$id_examen' AND numero='$ran2' ";
$res2=$link->query($pregunta2);
while ($row2=$res2->fetch_array()) {
$preg2=$row2['preg'];
$resp2=$row2['resp'];
$A2=$row2['A'];
$B2=$row2['B'];
$C2=$row2['C'];
$D2=$row2['D'];
}
$pdf->Ln();
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(10, 5, '', 0);
$pdf->SetTextColor(0, 255, 0);
$pdf->Cell(20, 5,'Pregunta 2. ', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(140, 5, $preg2, 0);
$pdf->Ln(4);


$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(A)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($A2), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(B)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($B2), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(C)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($C2), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(D)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($D2), 0);
$pdf->Ln(4);
if($resp2 == $A2){
  $resp2= "A";
}
if($resp2 == $B2){
  $resp2= "B";
}
if($resp2 == $C2){
  $resp2= "C";
}
if($resp2 == $D2){
  $resp2= "D";
}
$pdf->SetFont('Helvetica', 'B', 8);
$pdf->Cell(20, 5, '', 0);
$pdf->Cell(29, 5, utf8_decode('Respuesta Correcta'), 0);
$pdf->Cell(3, 5, ':', 0);
$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(60, 5, $resp2, 0);
if($resp2a == $A2){
  $resp2a= "A";
}
if($resp2a == $B2){
  $resp2a= "B";
}
if($resp2a == $C2){
  $resp2a= "C";
}
if($resp2a == $D2){
  $resp2a= "D";
}

$pdf->SetFont('Helvetica', 'B', 8);
$pdf->Cell(19, 4, utf8_decode('Tu respuesta'), 0);
$pdf->Cell(3, 4, ':', 0);
$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(60, 4, $resp2a, 0);
$pdf->Ln(4);
// HASTA AQUI PREGUNTA # 2
// desde aqui la PREGUNTA # 3
$pregunta3="SELECT * FROM preguntas WHERE id_examen='$id_examen' AND numero='$ran3' ";
$res3=$link->query($pregunta3);
while ($row3=$res3->fetch_array()) {
$preg3=$row3['preg'];
$resp3=$row3['resp'];
$A3=$row3['A'];
$B3=$row3['B'];
$C3=$row3['C'];
$D3=$row3['D'];
}
$pdf->Ln();
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(10, 5, '', 0);
$pdf->SetTextColor(0, 255, 0);
$pdf->Cell(20, 5, 'Pregunta 3. ', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(140, 5, $preg3, 0);
$pdf->Ln(4);


$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(A)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($A3), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(B)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($B3), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(C)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($C3), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(D)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($D3), 0);
$pdf->Ln(4);
if($resp3 == $A3){
  $resp3= "A";
}
if($resp3 == $B3){
  $resp3= "B";
}
if($resp3 == $C3){
  $resp3= "C";
}
if($resp3 == $D3){
  $resp3= "D";
}
$pdf->SetFont('Helvetica', 'B', 8);
$pdf->Cell(20, 5, '', 0);
$pdf->Cell(29, 5, utf8_decode('Respuesta Correcta'), 0);
$pdf->Cell(3, 5, ':', 0);
$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(60, 5, $resp3, 0);
if($resp3a == $A3){
  $resp3a= "A";
}
if($resp3a == $B3){
  $resp3a= "B";
}
if($resp3a == $C3){
  $resp3a= "C";
}
if($resp3a == $D3){
  $resp3a= "D";
}
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(19, 4, utf8_decode('Tu respuesta'), 0);
$pdf->Cell(3, 4, ':', 0);
$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(60, 4, $resp3a, 0);
$pdf->Ln(4);
// HASTA AQUI PREGUNTA # 3

// desde aqui la PREGUNTA # 4
$pregunta4="SELECT * FROM preguntas WHERE id_examen='$id_examen' AND numero='$ran4' ";
$res4=$link->query($pregunta4);
while ($row4=$res4->fetch_array()) {
$preg4=$row4['preg'];
$resp4=$row4['resp'];
$A4=$row4['A'];
$B4=$row4['B'];
$C4=$row4['C'];
$D4=$row4['D'];
}
$pdf->Ln();
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(10, 5, '', 0);
$pdf->SetTextColor(0, 255, 0);
$pdf->Cell(20, 5, ' Pregunta 4. ', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(140, 5, $preg4, 0);
$pdf->Ln(4);


$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(A)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($A4), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(B)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($B4), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(C)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($C4), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(D)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($D4), 0);
$pdf->Ln(4);
if($resp4 == $A4){
  $resp4= "A";
}
if($resp4 == $B4){
  $resp4= "B";
}
if($resp4 == $C4){
  $resp4= "C";
}
if($resp4 == $D4){
  $resp4= "D";
}
$pdf->SetFont('Helvetica', 'B', 8);
$pdf->Cell(20, 5, '', 0);
$pdf->Cell(29, 5, utf8_decode('Respuesta Correcta'), 0);
$pdf->Cell(3, 5, ':', 0);
$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(60, 5, $resp4, 0);
if($resp4a == $A4){
  $resp4a= "A";
}
if($resp4a == $B4){
  $resp4a= "B";
}
if($resp4a == $C4){
  $resp4a= "C";
}
if($resp4a == $D4){
  $resp4a= "D";
}
$pdf->SetFont('Helvetica', 'B', 8);
$pdf->Cell(19, 4, utf8_decode('Tu respuesta'), 0);
$pdf->Cell(3, 4, ':', 0);
$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(60, 4, $resp4a, 0);
$pdf->Ln(4);
// HASTA AQUI PREGUNTA # 4
// desde aqui la PREGUNTA # 5
$pregunta5="SELECT * FROM preguntas WHERE id_examen='$id_examen' AND numero='$ran5' ";
$res5=$link->query($pregunta5);
while ($row5=$res5->fetch_array()) {
$preg5=$row5['preg'];
$resp5=$row5['resp'];
$A5=$row5['A'];
$B5=$row5['B'];
$C5=$row5['C'];
$D5=$row5['D'];
}
$pdf->Ln();
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(10, 5, '', 0);
$pdf->SetTextColor(0, 255, 0);
$pdf->Cell(20, 5, 'Pregunta 5. ', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(140, 5, $preg5, 0);
$pdf->Ln(4);


$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(A)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($A5), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(B)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($B5), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(C)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($C5), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(D)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($D5), 0);
$pdf->Ln(4);
if($resp5 == $A5){
  $resp5= "A";
}
if($resp5 == $B5){
  $resp5= "B";
}
if($resp5 == $C5){
  $resp5= "C";
}
if($resp5 == $D5){
  $resp5= "D";
}
$pdf->SetFont('Helvetica', 'B', 8);
$pdf->Cell(20, 5, '', 0);
$pdf->Cell(29, 5, utf8_decode('Respuesta Correcta'), 0);
$pdf->Cell(3, 5, ':', 0);
$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(60, 5, $resp5, 0);

if($resp5a == $A5){
  $resp5a= "A";
}
if($resp5a == $B5){
  $resp5a= "B";
}
if($resp5a == $C5){
  $resp5a= "C";
}
if($resp5a == $D5){
  $resp5a= "D";
}
$pdf->SetFont('Helvetica', 'B', 8);
$pdf->Cell(19, 4, utf8_decode('Tu respuesta'), 0);
$pdf->Cell(3, 4, ':', 0);
$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(60, 4, $resp5a, 0);
$pdf->Ln(4);
// HASTA AQUI PREGUNTA # 5
// desde aqui la PREGUNTA # 6
$pregunta6="SELECT * FROM preguntas WHERE id_examen='$id_examen' AND numero='$ran6' ";
$res6=$link->query($pregunta6);
while ($row6=$res6->fetch_array()) {
$preg6=$row6['preg'];
$resp6=$row6['resp'];
$A6=$row6['A'];
$B6=$row6['B'];
$C6=$row6['C'];
$D6=$row6['D'];
}
$pdf->Ln();
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(10, 5, '', 0);
$pdf->SetTextColor(0, 255, 0);
$pdf->Cell(20, 5, 'Pregunta 6. ', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(140, 5, $preg6, 0);
$pdf->Ln(4);


$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(A)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($A6), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(B)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($B6), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(C)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($C6), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(D)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($D6), 0);
$pdf->Ln(4);

if($resp6 == $A6){
  $resp6= "A";
}
if($resp6 == $B6){
  $resp6= "B";
}
if($resp6 == $C6){
  $resp6= "C";
}
if($resp6 == $D6){
  $resp6= "D";
}
$pdf->SetFont('Helvetica', 'B', 8);
$pdf->Cell(20, 5, '', 0);
$pdf->Cell(29, 5, utf8_decode('Respuesta Correcta'), 0);
$pdf->Cell(3, 5, ':', 0);
$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(60, 5, $resp6, 0);

if($resp6a == $A6){
  $resp6a= "A";
}
if($resp6a == $B6){
  $resp6a= "B";
}
if($resp6a == $C6){
  $resp6a= "C";
}
if($resp6a == $D6){
  $resp6a= "D";
}
$pdf->SetFont('Helvetica', 'B', 8);
$pdf->Cell(19, 4, utf8_decode('Tu respuesta'), 0);
$pdf->Cell(3, 4, ':', 0);
$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(60, 4, $resp6a, 0);
$pdf->Ln(4);
// HASTA AQUI PREGUNTA # 6
// desde aqui la PREGUNTA # 7
$pregunta7="SELECT * FROM preguntas WHERE id_examen='$id_examen' AND numero='$ran7' ";
$res7=$link->query($pregunta7);
while ($row7=$res7->fetch_array()) {
$preg7=$row7['preg'];
$resp7=$row7['resp'];
$A7=$row7['A'];
$B7=$row7['B'];
$C7=$row7['C'];
$D7=$row7['D'];
}
$pdf->Ln();
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(10, 5, '', 0);
$pdf->SetTextColor(0, 255, 0);
$pdf->Cell(20, 5, 'Pregunta 7. ', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(140, 5, $preg7, 0);
$pdf->Ln(4);


$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(A)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($A7), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(B)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($B7), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(C)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($C7), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(D)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($D7), 0);
$pdf->Ln(4);

if($resp7 == $A7){
  $resp7= "A";
}
if($resp7 == $B7){
  $resp7= "B";
}
if($resp7 == $C7){
  $resp7= "C";
}
if($resp7 == $D7){
  $resp7= "D";
}
$pdf->SetFont('Helvetica', 'B', 8);
$pdf->Cell(20, 5, '', 0);
$pdf->Cell(29, 5, utf8_decode('Respuesta Correcta'), 0);
$pdf->Cell(3, 5, ':', 0);
$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(60, 5, $resp7, 0);
if($resp7a == $A7){
  $resp7a= "A";
}
if($resp7a == $B7){
  $resp7a= "B";
}
if($resp7a == $C7){
  $resp7a= "C";
}
if($resp7a == $D7){
  $resp7a= "D";
}
$pdf->SetFont('Helvetica', 'B', 8);
$pdf->Cell(19, 4, utf8_decode('Tu respuesta'), 0);
$pdf->Cell(3, 4, ':', 0);
$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(60, 4, $resp7a, 0);
$pdf->Ln(4);
// HASTA AQUI PREGUNTA # 7
// desde aqui la PREGUNTA # 8
$pregunta8="SELECT * FROM preguntas WHERE id_examen='$id_examen' AND numero='$ran8' ";
$res8=$link->query($pregunta8);
while ($row8=$res8->fetch_array()) {
$preg8=$row8['preg'];
$resp8=$row8['resp'];
$A8=$row8['A'];
$B8=$row8['B'];
$C8=$row8['C'];
$D8=$row8['D'];
}
$pdf->Ln();
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(10, 5, '', 0);
$pdf->SetTextColor(0, 255, 0);
$pdf->Cell(20, 5, 'Pregunta 8. ', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(140, 5, $preg8, 0);
$pdf->Ln(4);


$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(A)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($A8), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(B)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($B8), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(C)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($C8), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(D)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($D8), 0);
$pdf->Ln(4);

if($resp8 == $A8){
  $resp8= "A";
}
if($resp8 == $B8){
  $resp8= "B";
}
if($resp8 == $C8){
  $resp8= "C";
}
if($resp8 == $D8){
  $resp8= "D";
}
$pdf->SetFont('Helvetica', 'B', 8);
$pdf->Cell(20, 5, '', 0);
$pdf->Cell(29, 5, utf8_decode('Respuesta Correcta'), 0);
$pdf->Cell(3, 5, ':', 0);
$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(60, 5, $resp8, 0);

if($resp8a == $A8){
  $resp8a= "A";
}
if($resp8a == $B8){
  $resp8a= "B";
}
if($resp8a == $C8){
  $resp8a= "C";
}
if($resp8a == $D8){
  $resp8a= "D";
}
$pdf->SetFont('Helvetica', 'B', 8);
$pdf->Cell(19, 4, utf8_decode('Tu respuesta'), 0);
$pdf->Cell(3, 4, ':', 0);
$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(60, 4, $resp8a, 0);
$pdf->Ln(4);
// HASTA AQUI PREGUNTA # 8
// desde aqui la PREGUNTA # 9
$pregunta9="SELECT * FROM preguntas WHERE id_examen='$id_examen' AND numero='$ran9' ";
$res9=$link->query($pregunta9);
while ($row9=$res9->fetch_array()) {
$preg9=$row9['preg'];
$resp9=$row9['resp'];
$A9=$row9['A'];
$B9=$row9['B'];
$C9=$row9['C'];
$D9=$row9['D'];
}
$pdf->Ln();
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(10, 5, '', 0);
$pdf->SetTextColor(0, 255, 0);
$pdf->Cell(20, 5, 'Pregunta 9. ', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(140, 5, $preg9, 0);
$pdf->Ln(4);


$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(A)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($A9), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(B)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($B9), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(C)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($C9), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(D)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($D9), 0);
$pdf->Ln(4);

if($resp9 == $A9){
  $resp9= "A";
}
if($resp9 == $B9){
  $resp9= "B";
}
if($resp9 == $C9){
  $resp9= "C";
}
if($resp9 == $D9){
  $resp9= "D";
}
$pdf->SetFont('Helvetica', 'B', 8);
$pdf->Cell(20, 5, '', 0);
$pdf->Cell(29, 5, utf8_decode('Respuesta Correcta'), 0);
$pdf->Cell(3, 5, ':', 0);
$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(60, 5, $resp9, 0);

if($resp9a == $A9){
  $resp9a= "A";
}
if($resp9a == $B9){
  $resp9a= "B";
}
if($resp9a == $C9){
  $resp9a= "C";
}
if($resp9a == $D9){
  $resp9a= "D";
}
$pdf->SetFont('Helvetica', 'B', 8);
$pdf->Cell(19, 4, utf8_decode('Tu respuesta'), 0);
$pdf->Cell(3, 4, ':', 0);
$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(60, 4, $resp9a, 0);
$pdf->Ln(4);
// HASTA AQUI PREGUNTA # 9
// desde aqui la PREGUNTA # 10
$pregunta10="SELECT * FROM preguntas WHERE id_examen='$id_examen' AND numero='$ran10' ";
$res10=$link->query($pregunta10);
while ($row10=$res10->fetch_array()) {
$preg10=$row10['preg'];
$resp10=$row10['resp'];
$A10=$row10['A'];
$B10=$row10['B'];
$C10=$row10['C'];
$D10=$row10['D'];
}
$pdf->Ln();
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(10, 5, '', 0);
$pdf->SetTextColor(0, 255, 0);
$pdf->Cell(20, 5, 'Pregunta 10. ', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(140, 5, $preg10, 0);
$pdf->Ln(4);


$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(A)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($A10), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(B)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($B10), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(C)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($C10), 0);
$pdf->Ln(4);
$pdf->Cell(35, 5, '', 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(5, 5, '(D)', 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(135, 5, utf8_decode($D10), 0);
$pdf->Ln(4);

if($resp10 == $A10){
  $resp10= "A";
}
if($resp10 == $B10){
  $resp10= "B";
}
if($resp10 == $C10){
  $resp10= "C";
}
if($resp10 == $D10){
  $resp10= "D";
}

$pdf->SetFont('Helvetica', 'B', 8);
$pdf->Cell(20, 5, '', 0);
$pdf->Cell(29, 5, utf8_decode('Respuesta Correcta'), 0);
$pdf->Cell(3, 5, ':', 0);
$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(60, 5, $resp10, 0);

if($resp10a == $A10){
  $resp10a= "A";
}
if($resp10a == $B10){
  $resp10a= "B";
}
if($resp10a == $C10){
  $resp10a= "C";
}
if($resp10a == $D10){
  $resp10a= "D";
}
$pdf->SetFont('Helvetica', 'B', 8);
$pdf->Cell(19, 4, utf8_decode('Tu respuesta'), 0);
$pdf->Cell(3, 4, ':', 0);
$pdf->SetFont('Helvetica', '', 8);
$pdf->Cell(60, 4, $resp10a, 0);
$pdf->Ln(4);
// HASTA AQUI PREGUNTA # 9
$pdf->Output();
 }else{
  echo "No eres Administrador y No tienes Permiso para ver esta pagina ";
  echo "<a href ='../index.php' > REGRESAR </a>";
}?>