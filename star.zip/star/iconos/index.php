<?php
echo " Pagina se encuentra Vacia";
?>